import React from 'react'

type PropType = {
    selected: boolean
    imgSrc: string
    index: number
    onClick: () => void
}

export const Thumb: React.FC<PropType> = (props) => {
    const { selected, imgSrc, index, onClick } = props

    return (
        <div
            className={'embla-thumbs__slide'.concat(
                selected ? ' embla-thumbs__slide--selected' : ''
            )}
        >
            <button
                className="embla-thumbs__slide__button"
                type="button"
                onClick={onClick}
            >
                <div className="embla-thumbs__slide__number">
                    <span>{index + 1}</span>
                </div>
                <img
                    className="embla-thumbs__slide__img"
                    src={imgSrc}
                    alt="Your alt text"
                />
            </button>
        </div>
    )
}
